
package sp.pakvin.minecraftrewindforge.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ThePortalAtlasItem extends Item {
	public ThePortalAtlasItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}

	@Override
	public int getEnchantmentValue() {
		return 50;
	}
}
