
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package sp.pakvin.minecraftrewindforge.init;

import sp.pakvin.minecraftrewindforge.block.TheUnderneathPortalBlock;
import sp.pakvin.minecraftrewindforge.MinecraftRewindForgeMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class MinecraftRewindForgeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MinecraftRewindForgeMod.MODID);
	public static final RegistryObject<Block> THE_UNDERNEATH_PORTAL = REGISTRY.register("the_underneath_portal", () -> new TheUnderneathPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
