
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package sp.pakvin.minecraftrewindforge.init;

import sp.pakvin.minecraftrewindforge.item.TheUnderneathItem;
import sp.pakvin.minecraftrewindforge.item.ThePortalAtlasItem;
import sp.pakvin.minecraftrewindforge.item.TheAmuletItem;
import sp.pakvin.minecraftrewindforge.item.RomeosGlockItem;
import sp.pakvin.minecraftrewindforge.item.GauntletCoreItem;
import sp.pakvin.minecraftrewindforge.item.GauntletCore7Item;
import sp.pakvin.minecraftrewindforge.item.GauntletCore6Item;
import sp.pakvin.minecraftrewindforge.item.GauntletCore5Item;
import sp.pakvin.minecraftrewindforge.item.GauntletCore3Item;
import sp.pakvin.minecraftrewindforge.item.GauntletCore2Item;
import sp.pakvin.minecraftrewindforge.item.Gauntlet7CopperItem;
import sp.pakvin.minecraftrewindforge.item.Gauntlet6FredItem;
import sp.pakvin.minecraftrewindforge.item.Gauntlet5WarriorItem;
import sp.pakvin.minecraftrewindforge.item.Gauntlet3GoldProtocolItem;
import sp.pakvin.minecraftrewindforge.item.Gauntlet2ChampionItem;
import sp.pakvin.minecraftrewindforge.item.Gauntlet1PrismarineItem;
import sp.pakvin.minecraftrewindforge.item.EnchantedFlintAndSteelItem;
import sp.pakvin.minecraftrewindforge.MinecraftRewindForgeMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

public class MinecraftRewindForgeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MinecraftRewindForgeMod.MODID);
	public static final RegistryObject<Item> GAUNTLET_1_PRISMARINE = REGISTRY.register("gauntlet_1_prismarine", () -> new Gauntlet1PrismarineItem());
	public static final RegistryObject<Item> GAUNTLET_2_CHAMPION = REGISTRY.register("gauntlet_2_champion", () -> new Gauntlet2ChampionItem());
	public static final RegistryObject<Item> GAUNTLET_3_GOLD_PROTOCOL = REGISTRY.register("gauntlet_3_gold_protocol", () -> new Gauntlet3GoldProtocolItem());
	public static final RegistryObject<Item> ROMEOS_GLOCK = REGISTRY.register("romeos_glock", () -> new RomeosGlockItem());
	public static final RegistryObject<Item> GAUNTLET_5_WARRIOR = REGISTRY.register("gauntlet_5_warrior", () -> new Gauntlet5WarriorItem());
	public static final RegistryObject<Item> GAUNTLET_6_FRED = REGISTRY.register("gauntlet_6_fred", () -> new Gauntlet6FredItem());
	public static final RegistryObject<Item> THE_AMULET = REGISTRY.register("the_amulet", () -> new TheAmuletItem());
	public static final RegistryObject<Item> THE_PORTAL_ATLAS = REGISTRY.register("the_portal_atlas", () -> new ThePortalAtlasItem());
	public static final RegistryObject<Item> ENCHANTED_FLINT_AND_STEEL = REGISTRY.register("enchanted_flint_and_steel", () -> new EnchantedFlintAndSteelItem());
	public static final RegistryObject<Item> THE_UNDERNEATH = REGISTRY.register("the_underneath", () -> new TheUnderneathItem());
	public static final RegistryObject<Item> GAUNTLET_CORE = REGISTRY.register("gauntlet_core", () -> new GauntletCoreItem());
	public static final RegistryObject<Item> GAUNTLET_CORE_2 = REGISTRY.register("gauntlet_core_2", () -> new GauntletCore2Item());
	public static final RegistryObject<Item> GAUNTLET_CORE_3 = REGISTRY.register("gauntlet_core_3", () -> new GauntletCore3Item());
	public static final RegistryObject<Item> GAUNTLET_CORE_5 = REGISTRY.register("gauntlet_core_5", () -> new GauntletCore5Item());
	public static final RegistryObject<Item> GAUNTLET_CORE_6 = REGISTRY.register("gauntlet_core_6", () -> new GauntletCore6Item());
	public static final RegistryObject<Item> GAUNTLET_7_COPPER = REGISTRY.register("gauntlet_7_copper", () -> new Gauntlet7CopperItem());
	public static final RegistryObject<Item> GAUNTLET_CORE_7 = REGISTRY.register("gauntlet_core_7", () -> new GauntletCore7Item());
	// Start of user code block custom items
	// End of user code block custom items
}
