
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package sp.pakvin.minecraftrewindforge.init;

import sp.pakvin.minecraftrewindforge.MinecraftRewindForgeMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MinecraftRewindForgeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MinecraftRewindForgeMod.MODID);
	public static final RegistryObject<CreativeModeTab> MINECRAFT_REWIND_TAB = REGISTRY.register("minecraft_rewind_tab", () -> CreativeModeTab.builder().title(Component.translatable("item_group.minecraft_rewind_forge.minecraft_rewind_tab"))
			.icon(() -> new ItemStack(MinecraftRewindForgeModItems.GAUNTLET_1_PRISMARINE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_1_PRISMARINE.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_2_CHAMPION.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_3_GOLD_PROTOCOL.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_5_WARRIOR.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_6_FRED.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_7_COPPER.get());
				tabData.accept(MinecraftRewindForgeModItems.THE_AMULET.get());
				tabData.accept(MinecraftRewindForgeModItems.THE_PORTAL_ATLAS.get());
				tabData.accept(MinecraftRewindForgeModItems.ENCHANTED_FLINT_AND_STEEL.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE_2.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE_3.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE_5.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE_6.get());
				tabData.accept(MinecraftRewindForgeModItems.GAUNTLET_CORE_7.get());
				tabData.accept(MinecraftRewindForgeModItems.THE_UNDERNEATH.get());
				tabData.accept(MinecraftRewindForgeModItems.ROMEOS_GLOCK.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MinecraftRewindForgeModItems.THE_UNDERNEATH.get());
		}
	}
}
